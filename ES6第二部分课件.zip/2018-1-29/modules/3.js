export default 12;

export const cc=12;
export const dd=5;