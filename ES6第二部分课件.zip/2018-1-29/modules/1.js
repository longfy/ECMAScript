console.log('1模块加载了');
export const a =12;
export const b = 5;
export let c = 101;