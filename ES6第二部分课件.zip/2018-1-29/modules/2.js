const a=12;
const b=5;
const c=101;

export {
    a as aaa,
    b as banana,
    c as cup
}