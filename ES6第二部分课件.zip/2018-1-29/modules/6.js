let a = 12;
let b = 5;

setTimeout(()=>{
    a=1111111;
},2000);

export {
    a,
    b
}